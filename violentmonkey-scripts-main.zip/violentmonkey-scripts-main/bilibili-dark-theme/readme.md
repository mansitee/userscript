# bilibili-dark-theme

> b 站夜间模式

[![2024-04-21-110337.png](https://i.postimg.cc/jdnjpg0X/2024-04-21-110337.png)](https://postimg.cc/0bxxmCNM)

## 安装

[Greasy Fork](https://greasyfork.org/zh-CN/scripts/493049-bilibili-dark-theme)

## 更新历史

**v1.2 2024/5/6**

> 添加搜索页夜间模式支持  
> 去除 header 阴影改用 border

**v1.1 2024/5/4**

> 添加动态页夜间模式支持

**v1.0 2024/4/20**
