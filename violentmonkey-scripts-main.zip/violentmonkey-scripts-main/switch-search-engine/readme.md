# switch-search-engine

> 为你的搜索页面添加快速切换搜索引擎的功能

[![switch-search-engine-preview.png](https://i.postimg.cc/y6gtbtPJ/switch-search-engine-preview.png)](https://postimg.cc/pyvs903x)

## 安装

[Greasy Fork](https://greasyfork.org/zh-CN/scripts/490645-switch-search-engine)
