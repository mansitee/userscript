# bilibili-roll-history

> 为 b 站“摇一摇”功能添加回溯历史功能  
> powerd by [biliplus](https://github.com/0xlau/biliplus)

[![bilibili-roll-history-preview.png](https://i.postimg.cc/nr8Zg1S4/bilibili-roll-history-preview.png)](https://postimg.cc/Fdx2J04z)

## 安装

[Greasy Fork](https://greasyfork.org/zh-CN/scripts/490584-bilibili-roll-history)

## 更新历史

**v1.2 2024/5/8**

> 修复 firefox 中没有生效的问题

**v1.1**

> 性能优化

**v1.0**
