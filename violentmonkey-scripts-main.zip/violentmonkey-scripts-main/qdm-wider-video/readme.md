# qdm-wider-video

> 让趣动漫的视频播放器宽屏播放（并且移除了页面中的一些干扰元素，更专注视频）。

[![2024-05-06-231043.png](https://i.postimg.cc/Pq0LCHgC/2024-05-06-231043.png)](https://postimg.cc/GBJ3fWhR)

## 安装

[Greasy Fork](https://greasyfork.org/zh-CN/scripts/494244-qdm-wider-video)

## 更新历史

**v1.1 2024/5/7**

> 使剧集排布更加紧凑

**v1.0 2024/5/6**
