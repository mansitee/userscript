# bilibili-friendly-ads

## **deprecate! 截至 2024-4-21，b 站已经为 adb 类插件提供正常屏蔽提示服务，本脚本暂停维护。**

> 为 b 站**首页**提供更友好的广告屏蔽服务（[AdBlock](https://getadblock.com/zh_CN/)在 b 站上的广告屏蔽表现为空白形式，本插件将其替换为占位符号）

[![bilibili-friendly-ads-preview.png](https://i.postimg.cc/L50NYPbN/bilibili-friendly-ads-preview.png)](https://postimg.cc/4HVzjYZ9)

## 安装

[Greasy Fork](https://greasyfork.org/zh-CN/scripts/490630-bilibili-frendly-ads)

## 更新记录

**v2.0 2024/3/28**

优化性能，修复某些情况下的白屏，添加非 feed 视频的广告屏蔽

**v1.0 2024/3/22**
