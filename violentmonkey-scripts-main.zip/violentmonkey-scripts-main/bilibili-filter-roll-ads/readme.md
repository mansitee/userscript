# bilibili-filter-roll-ads

> 过滤 b 站换一换广告

[![2024-04-21-111911.png](https://i.postimg.cc/4yvn0PSP/2024-04-21-111911.png)](https://postimg.cc/RJFM679J)

## 安装

[Greasy Fork](https://greasyfork.org/zh-CN/scripts/493050-bilibili-filter-roll-ads)

### 更新历史

**2024/4/26 v1.1**

修复 ps 参数错误问题。  
不再剪切数组长度。

**2024/4/21 v1.0**
